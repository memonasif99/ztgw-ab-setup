variable "project_name" {
  description = "Short identifier used in resource names"
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev | staging | prod)"
  type        = string
}

variable "suffix" {
  description = "Random 5-char alphanumeric suffix appended to all resource names"
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC to place the bastion security group in"
  type        = string
}

variable "subnet_id" {
  description = "ID of the public subnet to deploy the bastion host in"
  type        = string
}

variable "key_name" {
  description = "EC2 Key Pair name for SSH access"
  type        = string
}

variable "instance_type" {
  description = "EC2 instance type for the bastion host"
  type        = string
  default     = "t3.micro"
}

variable "ssh_allowed_cidrs" {
  description = "CIDRs permitted to SSH to the bastion. Restrict to your IP in production."
  type        = list(string)
  default     = ["0.0.0.0/0"]
}

variable "tags" {
  description = "Additional tags to merge on every resource"
  type        = map(string)
  default     = {}
}
