########################################################################
# Module: vpc
# Creates: 1 VPC + 1 Internet Gateway
########################################################################

resource "aws_vpc" "main" {
  cidr_block           = var.vpc_cidr
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-vpc"
  })
}

resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-igw"
  })
}

# ── VPC Flow Logs ─────────────────────────────────────────────────────
resource "aws_cloudwatch_log_group" "flow_logs" {
  count             = var.enable_flow_logs ? 1 : 0
  name              = "/aws/vpc/${local.prefix}-flow-logs"
  retention_in_days = var.flow_logs_retention_days
  tags              = local.common_tags

  # skip_destroy = false is the default, stated explicitly so that it is
  # obvious this group WILL be deleted on terraform destroy. If you need
  # to preserve flow logs across a destroy, set this to true.
  skip_destroy = false
}

resource "aws_iam_role" "flow_logs" {
  count                 = var.enable_flow_logs ? 1 : 0
  name                  = "${local.prefix}-flow-logs-role"
  force_detach_policies = true

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "vpc-flow-logs.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy" "flow_logs" {
  count = var.enable_flow_logs ? 1 : 0
  name  = "${local.prefix}-flow-logs-policy"
  role  = aws_iam_role.flow_logs[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "logs:CreateLogStream",
        "logs:PutLogEvents",
        "logs:DescribeLogGroups",
        "logs:DescribeLogStreams",
      ]
      Resource = [
          aws_cloudwatch_log_group.flow_logs[0].arn,
          "${aws_cloudwatch_log_group.flow_logs[0].arn}:*",
        ]
    }]
  })
}

resource "aws_flow_log" "main" {
  count                = var.enable_flow_logs ? 1 : 0
  vpc_id               = aws_vpc.main.id
  traffic_type         = "ALL"
  iam_role_arn         = aws_iam_role.flow_logs[0].arn
  log_destination_type = "cloud-watch-logs"
  log_destination      = aws_cloudwatch_log_group.flow_logs[0].arn

  # Explicit dependency ensures the flow log is destroyed before the log
  # group on terraform destroy, preventing the group from being orphaned
  # while a flow log is still actively writing to it.
  depends_on = [aws_cloudwatch_log_group.flow_logs]

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-flow-logs"
  })
}

locals {
  prefix = "${var.project_name}-${var.environment}-${var.suffix}"

  common_tags = merge(var.tags, {
    Module = "vpc"
  })
}
