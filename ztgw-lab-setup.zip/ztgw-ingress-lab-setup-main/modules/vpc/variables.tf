variable "project_name" {
  description = "Project identifier prefix"
  type        = string
}

variable "environment" {
  description = "Deployment environment"
  type        = string
}

variable "suffix" {
  description = "Random 5-char alphanumeric suffix appended to all resource names"
  type        = string
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
}

variable "enable_flow_logs" {
  description = "Enable VPC Flow Logs to CloudWatch Logs (ALL traffic)"
  type        = bool
  default     = true
}

variable "flow_logs_retention_days" {
  description = "CloudWatch log group retention period for flow logs (days)"
  type        = number
  default     = 30
}

variable "tags" {
  description = "Additional resource tags"
  type        = map(string)
  default     = {}
}
