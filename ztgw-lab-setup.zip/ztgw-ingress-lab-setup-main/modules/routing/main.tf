########################################################################
# Module: routing
#
# Route Tables and routes:
#   1. igw_rt       — Edge RT on IGW; routes each public subnet CIDR
#                     to the GWLB endpoint in the same AZ
#   2. public_rt    — 0.0.0.0/0 → GWLB endpoint (one RT per public subnet,
#                     endpoint matched by AZ)
#   3. private_rt   — 0.0.0.0/0 → GWLB endpoint (one RT per app subnet,
#                     endpoint matched by AZ)
#   4. gwlb_rt      — 0.0.0.0/0 → IGW (shared by both GWLB subnets)
########################################################################

# ── 1. IGW Route Table (Gateway / Edge Association) ───────────────────
# This RT is edge-associated with the IGW, enabling ingress routing
# inspection if a security appliance sits between IGW and public subnets.
resource "aws_route_table" "igw" {
  vpc_id = var.vpc_id

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-igw-rt"
    Type = "igw-edge"
  })
}

resource "aws_route_table_association" "igw" {
  gateway_id     = var.igw_id
  route_table_id = aws_route_table.igw.id
}

# Redirect inbound traffic for each public subnet through the GWLB endpoint
# in the same AZ before it reaches the subnet. Index alignment:
#   public_subnet_cidrs[0] / gwlb_endpoint_ids[0] → AZ-a
#   public_subnet_cidrs[1] / gwlb_endpoint_ids[1] → AZ-b
resource "aws_route" "igw_to_gwlb" {
  for_each = zipmap(var.public_subnet_cidrs, var.gwlb_endpoint_ids)

  route_table_id         = aws_route_table.igw.id
  destination_cidr_block = each.key
  vpc_endpoint_id        = each.value
}

# ── 2. Public Route Tables — one per public subnet ────────────────────
# One RT per subnet so each AZ's traffic hits the GWLB endpoint in the
# same AZ (symmetrical traffic flow required by GWLB inspection).
resource "aws_route_table" "public" {
  count  = length(var.public_subnet_ids)
  vpc_id = var.vpc_id

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-public-rt-${count.index + 1}"
    Type = "public"
  })
}

resource "aws_route_table_association" "public" {
  count = length(var.public_subnet_ids)

  subnet_id      = var.public_subnet_ids[count.index]
  route_table_id = aws_route_table.public[count.index].id
}

resource "aws_route" "public_to_gwlb" {
  count = length(var.public_subnet_ids)

  route_table_id         = aws_route_table.public[count.index].id
  destination_cidr_block = "0.0.0.0/0"
  vpc_endpoint_id        = var.gwlb_endpoint_ids[count.index]
}

# ── 3. Private App Route Tables — one per app subnet ──────────────────
# One RT per subnet keeps AZ-level routing independent.
resource "aws_route_table" "private" {
  count  = length(var.private_app_subnet_ids)
  vpc_id = var.vpc_id

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-private-app-rt-${count.index + 1}"
    Type = "private-app"
  })
}

resource "aws_route_table_association" "private" {
  count = length(var.private_app_subnet_ids)

  subnet_id      = var.private_app_subnet_ids[count.index]
  route_table_id = aws_route_table.private[count.index].id
}

# Default route for each app subnet → GWLB endpoint in the same AZ.
# gwlb_endpoint_ids[i] is the endpoint whose subnet shares AZ with
# private_app_subnet_ids[i].
resource "aws_route" "private_to_gwlb" {
  count = length(var.private_app_subnet_ids)

  route_table_id         = aws_route_table.private[count.index].id
  destination_cidr_block = "0.0.0.0/0"
  vpc_endpoint_id        = var.gwlb_endpoint_ids[count.index]
}

# ── 4. GWLB Route Table — shared by both private-gwlb subnets ─────────
resource "aws_route_table" "gwlb" {
  vpc_id = var.vpc_id

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-gwlb-rt"
    Type = "private-gwlb"
  })
}

resource "aws_route_table_association" "gwlb" {
  count = length(var.private_gwlb_subnet_ids)

  subnet_id      = var.private_gwlb_subnet_ids[count.index]
  route_table_id = aws_route_table.gwlb.id
}

# Return path: GWLB subnets send all traffic back out through the IGW.
resource "aws_route" "gwlb_to_igw" {
  route_table_id         = aws_route_table.gwlb.id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = var.igw_id
}

locals {
  prefix = "${var.project_name}-${var.environment}-${var.suffix}"

  common_tags = merge(var.tags, {
    Module = "routing"
  })
}
