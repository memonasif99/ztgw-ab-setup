output "igw_route_table_id" {
  description = "ID of the IGW gateway (edge) route table"
  value       = aws_route_table.igw.id
}

output "public_route_table_ids" {
  description = "IDs of the per-public-subnet route tables (index matches subnet index)"
  value       = aws_route_table.public[*].id
}

output "private_app_route_table_ids" {
  description = "IDs of the per-app-subnet route tables (index matches subnet index)"
  value       = aws_route_table.private[*].id
}

output "gwlb_route_table_id" {
  description = "ID of the shared GWLB route table"
  value       = aws_route_table.gwlb.id
}
