variable "project_name" {
  description = "Short identifier used in resource names"
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev | staging | prod)"
  type        = string
}

variable "suffix" {
  description = "Random 5-char alphanumeric suffix appended to all resource names"
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC to create route tables in"
  type        = string
}

variable "igw_id" {
  description = "ID of the Internet Gateway for the public default route"
  type        = string
}

variable "public_subnet_ids" {
  description = "IDs of public subnets to associate with the public route table"
  type        = list(string)
}

variable "public_subnet_cidrs" {
  description = "CIDR blocks of public subnets (AZ-ordered, matches public_subnet_ids) — used for IGW edge RT routes"
  type        = list(string)

  validation {
    condition     = length(var.public_subnet_cidrs) >= 2
    error_message = "At least 2 public subnet CIDRs are required (one per AZ)."
  }
}

variable "gwlb_endpoint_ids" {
  description = "GWLB endpoint IDs ordered by AZ (index 0 = AZ-a, 1 = AZ-b) — used as next-hop for GWLB routes"
  type        = list(string)

  validation {
    condition     = length(var.gwlb_endpoint_ids) >= 2
    error_message = "At least 2 GWLB endpoint IDs are required (one per AZ)."
  }
}

variable "private_app_subnet_ids" {
  description = "IDs of private app-tier subnets — one dedicated route table is created per subnet"
  type        = list(string)
}

variable "private_gwlb_subnet_ids" {
  description = "IDs of private GWLB endpoint subnets — both share a single route table"
  type        = list(string)
}

variable "tags" {
  type    = map(string)
  default = {}
}
