output "public_subnet_ids" {
  description = "IDs of the 2 public subnets"
  value       = aws_subnet.public[*].id
}

output "private_subnet_ids" {
  description = "IDs of all 4 private subnets (index 0-1 = app, 2-3 = gwlb)"
  value       = aws_subnet.private[*].id
}

output "private_app_subnet_ids" {
  description = "IDs of the 2 private app-tier subnets (indices 0-1)"
  value       = slice(aws_subnet.private[*].id, 0, 2)
}

output "private_gwlb_subnet_ids" {
  description = "IDs of the 2 private ZTG GWLB endpoint subnets (indices 2-3)"
  value       = slice(aws_subnet.private[*].id, 2, 4)
}

output "public_subnet_cidrs" {
  description = "CIDR blocks of the public subnets"
  value       = aws_subnet.public[*].cidr_block
}

output "private_subnet_cidrs" {
  description = "CIDR blocks of the private subnets"
  value       = aws_subnet.private[*].cidr_block
}
