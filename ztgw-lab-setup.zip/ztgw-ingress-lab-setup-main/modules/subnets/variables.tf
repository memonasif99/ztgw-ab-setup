variable "project_name" {
  description = "Short identifier used in resource names"
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev | staging | prod)"
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC to create subnets in"
  type        = string
}

variable "suffix" {
  description = "Random 5-char alphanumeric suffix appended to all resource names"
  type        = string
}

variable "availability_zones" {
  description = "List of 2 AZs"
  type        = list(string)
}

variable "public_subnet_cidrs" {
  description = "CIDR list for 2 public subnets"
  type        = list(string)
}

variable "private_subnet_cidrs" {
  description = "CIDR list for 4 private subnets"
  type        = list(string)
}

variable "tags" {
  type    = map(string)
  default = {}
}
