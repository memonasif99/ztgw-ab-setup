########################################################################
# Module: subnets
# Creates:
#   - 2 public  subnets (AZ-a, AZ-b) — map_public_ip_on_launch = true
#   - 4 private subnets (2 per AZ):
#       [0] private-app-1   (AZ-a)
#       [1] private-app-2   (AZ-b)
#       [2] private-gwlb-1  (AZ-a)   ← ZTG GWLB endpoints
#       [3] private-gwlb-2  (AZ-b)   ← ZTG GWLB endpoints
########################################################################

# ── Public Subnets ────────────────────────────────────────────────────
resource "aws_subnet" "public" {
  count = length(var.public_subnet_cidrs)

  vpc_id                  = var.vpc_id
  cidr_block              = var.public_subnet_cidrs[count.index]
  availability_zone       = var.availability_zones[count.index]
  map_public_ip_on_launch = true

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-public-subnet-${count.index + 1}"
    Tier = "public"
    AZ   = var.availability_zones[count.index]
  })
}

# ── Private Subnets ───────────────────────────────────────────────────
resource "aws_subnet" "private" {
  count = length(var.private_subnet_cidrs)

  vpc_id            = var.vpc_id
  cidr_block        = var.private_subnet_cidrs[count.index]
  availability_zone = var.availability_zones[count.index % length(var.availability_zones)]

  tags = merge(local.common_tags, {
    # Subnet naming: index 0,1 → app tier; 2,3 → ZTG GWLB endpoint tier
    Name = "${local.prefix}-private-subnet-${count.index + 1}"
    Tier = count.index < 2 ? "private-app" : "private-gwlb"
    AZ   = var.availability_zones[count.index % length(var.availability_zones)]
  })
}

locals {
  prefix = "${var.project_name}-${var.environment}-${var.suffix}"

  common_tags = merge(var.tags, {
    Module = "subnets"
  })
}
