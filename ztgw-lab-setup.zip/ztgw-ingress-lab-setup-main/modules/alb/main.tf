########################################################################
# Module: alb
# Creates:
#   - Application Load Balancer (internet-facing) in public subnets
#   - Target Group for NGINX EC2 instances (HTTP:80 with health check)
#   - HTTP:80 listener → forward to target group
########################################################################

resource "aws_lb" "main" {
  name               = local.prefix   # no component suffix — prefix+suffix already uses ~29 chars, "-alb" would exceed the 32-char limit
  internal           = false
  load_balancer_type = "application"
  security_groups    = [var.alb_sg_id]
  subnets            = var.public_subnet_ids

  enable_deletion_protection   = var.enable_deletion_protection
  drop_invalid_header_fields   = true

  # Access logs (enable in production)
  # access_logs {
  #   bucket  = aws_s3_bucket.alb_logs.id
  #   prefix  = "alb"
  #   enabled = true
  # }

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-alb"   # tag carries the descriptive label
  })

  lifecycle {
    precondition {
      condition     = length(local.prefix) <= 32
      error_message = "ALB name '${local.prefix}' exceeds the AWS 32-character limit. Shorten project_name or environment."
    }
  }
}

# ── Target Group ─────────────────────────────────────────────────────
resource "aws_lb_target_group" "nginx" {
  name        = "${local.prefix}-tg"
  port        = 80
  protocol    = "HTTP"
  vpc_id      = var.vpc_id
  target_type = "instance"

  # Deregistration delay — shorten for faster rolling deploys
  deregistration_delay = 30

  health_check {
    enabled             = true
    path                = "/health"
    port                = "traffic-port"
    protocol            = "HTTP"
    healthy_threshold   = 2
    unhealthy_threshold = 3
    timeout             = 5
    interval            = 30
    matcher             = "200-299"
  }

  stickiness {
    type            = "lb_cookie"
    cookie_duration = 86400
    enabled         = false # Enable if session persistence is needed
  }

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-nginx-tg"  # tag has no length limit; keep descriptive
  })

  lifecycle {
    precondition {
      condition     = length("${local.prefix}-tg") <= 32
      error_message = "Target group name '${local.prefix}-tg' exceeds the AWS 32-character limit. Shorten project_name or environment."
    }
  }
}

# ── HTTP Listener ─────────────────────────────────────────────────────
# In production: redirect HTTP → HTTPS, and add an HTTPS listener with ACM cert.
resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.main.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.nginx.arn
  }

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-http-listener"
  })
}

# ── HTTPS Listener template (uncomment when ACM cert is ready) ────────
# resource "aws_lb_listener" "https" {
#   load_balancer_arn = aws_lb.main.arn
#   port              = 443
#   protocol          = "HTTPS"
#   ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
#   certificate_arn   = var.acm_certificate_arn
#
#   default_action {
#     type             = "forward"
#     target_group_arn = aws_lb_target_group.nginx.arn
#   }
# }

locals {
  prefix = "${var.project_name}-${var.environment}-${var.suffix}"

  common_tags = merge(var.tags, {
    Module = "alb"
  })
}
