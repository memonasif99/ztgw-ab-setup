output "alb_arn" {
  description = "ARN of the Application Load Balancer"
  value       = aws_lb.main.arn
}

output "alb_dns_name" {
  description = "Public DNS name of the ALB — use this to reach NGINX"
  value       = aws_lb.main.dns_name
}

output "alb_zone_id" {
  description = "Hosted zone ID of the ALB (for Route 53 alias records)"
  value       = aws_lb.main.zone_id
}

output "target_group_arn" {
  description = "ARN of the NGINX target group"
  value       = aws_lb_target_group.nginx.arn
}

output "http_listener_arn" {
  description = "ARN of the HTTP:80 listener"
  value       = aws_lb_listener.http.arn
}
