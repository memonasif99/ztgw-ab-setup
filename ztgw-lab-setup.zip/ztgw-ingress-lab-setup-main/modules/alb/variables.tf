variable "project_name" {
  description = "Short identifier used in resource names"
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev | staging | prod)"
  type        = string
}

variable "suffix" {
  description = "Random 5-char alphanumeric suffix appended to all resource names"
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC the ALB is deployed into"
  type        = string
}

variable "public_subnet_ids" {
  description = "IDs of the public subnets for the ALB"
  type        = list(string)
}

variable "alb_sg_id" {
  description = "Security group ID to attach to the ALB"
  type        = string
}

variable "enable_deletion_protection" {
  description = "Prevent accidental ALB deletion; set true for staging and prod"
  type        = bool
  default     = false
}

variable "tags" {
  description = "Additional tags to merge on every resource"
  type        = map(string)
  default     = {}
}
