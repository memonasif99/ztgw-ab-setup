variable "project_name" {
  description = "Short identifier used in resource names"
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev | staging | prod)"
  type        = string
}

variable "suffix" {
  description = "Random 5-char alphanumeric suffix appended to all resource names"
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC to create the GWLB endpoints in"
  type        = string
}

variable "subnet_az_map" {
  description = "Map of AZ name → subnet ID for GWLB endpoint placement (one entry per AZ)"
  type        = map(string)
}

variable "endpoint_service_name" {
  description = "VPC endpoint service name from the remote GWLB account (e.g. com.amazonaws.vpce.<region>.<svc-id>)"
  type        = string
}

variable "tags" {
  description = "Additional tags to merge on every resource"
  type        = map(string)
  default     = {}
}
