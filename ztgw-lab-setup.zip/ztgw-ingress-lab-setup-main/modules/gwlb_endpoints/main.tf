########################################################################
# Module: gwlb_endpoints
# Creates:
#   - 1 Gateway Load Balancer VPC endpoint per subnet (one per AZ)
#   - Endpoints connect to an endpoint service in a remote AWS account
#
# NOTE: If the remote service does not have auto-accept enabled, the
#       service owner must manually accept the connection request before
#       endpoints reach the "available" state.
########################################################################

resource "aws_vpc_endpoint" "gwlb" {
  for_each = var.subnet_az_map   # key = AZ name (static), value = subnet ID

  vpc_id            = var.vpc_id
  service_name      = var.endpoint_service_name
  vpc_endpoint_type = "GatewayLoadBalancer"
  subnet_ids        = [each.value]

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-gwlb-ep-${each.key}"
    AZ   = each.key
  })
}

locals {
  prefix = "${var.project_name}-${var.environment}-${var.suffix}"

  common_tags = merge(var.tags, {
    Module = "gwlb_endpoints"
  })
}
