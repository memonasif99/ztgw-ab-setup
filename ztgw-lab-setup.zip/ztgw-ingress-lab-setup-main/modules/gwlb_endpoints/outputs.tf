output "endpoint_ids" {
  description = "Map of AZ name → GWLB endpoint ID"
  value       = { for az, ep in aws_vpc_endpoint.gwlb : az => ep.id }
}

output "endpoint_states" {
  description = "Map of AZ name → GWLB endpoint state (pendingAcceptance | available | ...)"
  value       = { for az, ep in aws_vpc_endpoint.gwlb : az => ep.state }
}

output "endpoint_arns" {
  description = "Map of AZ name → GWLB endpoint ARN"
  value       = { for az, ep in aws_vpc_endpoint.gwlb : az => ep.arn }
}
