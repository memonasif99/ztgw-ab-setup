variable "project_name" {
  description = "Short identifier used in resource names"
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev | staging | prod)"
  type        = string
}

variable "suffix" {
  description = "Random 5-char alphanumeric suffix appended to all resource names"
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC to create security groups in"
  type        = string
}

variable "ssh_allowed_cidrs" {
  description = "CIDR ranges permitted to SSH into EC2 instances"
  type        = list(string)
  default     = ["10.0.0.0/8"]
}

variable "tags" {
  type    = map(string)
  default = {}
}
