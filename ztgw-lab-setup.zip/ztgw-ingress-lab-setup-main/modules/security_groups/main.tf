########################################################################
# Module: security_groups
# Creates:
#   alb_sg  — Accepts 80/443 from 0.0.0.0/0; egress to EC2 SG on 80
#   ec2_sg  — Accepts 80 only from alb_sg; SSH from var.ssh_allowed_cidrs
########################################################################

# ── ALB Security Group ────────────────────────────────────────────────
resource "aws_security_group" "alb" {
  name        = "${local.prefix}-alb-sg"
  description = "Allow HTTP/HTTPS inbound from internet to ALB"
  vpc_id      = var.vpc_id

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-alb-sg"
  })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "alb_http" {
  security_group_id = aws_security_group.alb.id
  description       = "HTTP from internet"
  ip_protocol       = "tcp"
  from_port         = 80
  to_port           = 80
  cidr_ipv4         = "0.0.0.0/0"
}

resource "aws_vpc_security_group_ingress_rule" "alb_https" {
  security_group_id = aws_security_group.alb.id
  description       = "HTTPS from internet"
  ip_protocol       = "tcp"
  from_port         = 443
  to_port           = 443
  cidr_ipv4         = "0.0.0.0/0"
}

# ALB egress: only to EC2 SG on port 80 (principle of least privilege)
resource "aws_vpc_security_group_egress_rule" "alb_to_ec2" {
  security_group_id            = aws_security_group.alb.id
  description                  = "Forward HTTP traffic to EC2 instances"
  ip_protocol                  = "tcp"
  from_port                    = 80
  to_port                      = 80
  referenced_security_group_id = aws_security_group.ec2.id
}

# ── EC2 Security Group ────────────────────────────────────────────────
resource "aws_security_group" "ec2" {
  name        = "${local.prefix}-ec2-sg"
  description = "Allow HTTP from ALB only; SSH from approved CIDRs"
  vpc_id      = var.vpc_id

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-ec2-sg"
  })

  lifecycle {
    create_before_destroy = true
  }
}

# HTTP from ALB only — source is ALB security group ID
resource "aws_vpc_security_group_ingress_rule" "ec2_http_from_alb" {
  security_group_id            = aws_security_group.ec2.id
  description                  = "HTTP from ALB security group"
  ip_protocol                  = "tcp"
  from_port                    = 80
  to_port                      = 80
  referenced_security_group_id = aws_security_group.alb.id
}

# SSH from restricted CIDR (bastion / VPN)
resource "aws_vpc_security_group_ingress_rule" "ec2_ssh" {
  for_each = toset(var.ssh_allowed_cidrs)

  security_group_id = aws_security_group.ec2.id
  description       = "SSH access from ${each.value}"
  ip_protocol       = "tcp"
  from_port         = 22
  to_port           = 22
  cidr_ipv4         = each.value
}

# EC2 egress: all traffic (needed for apt-get, HTTPS calls, etc.)
resource "aws_vpc_security_group_egress_rule" "ec2_all_out" {
  security_group_id = aws_security_group.ec2.id
  description       = "All outbound traffic"
  ip_protocol       = "-1"
  cidr_ipv4         = "0.0.0.0/0"
}

locals {
  prefix = "${var.project_name}-${var.environment}-${var.suffix}"

  common_tags = merge(var.tags, {
    Module = "security_groups"
  })
}
