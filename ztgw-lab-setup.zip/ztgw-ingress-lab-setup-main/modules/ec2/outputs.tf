output "instance_ids" {
  description = "IDs of the NGINX EC2 instances"
  value       = [for inst in aws_instance.nginx : inst.id]
}

output "private_ips" {
  description = "Private IP addresses of the NGINX EC2 instances"
  value       = [for inst in aws_instance.nginx : inst.private_ip]
}

output "ami_id" {
  description = "Ubuntu 22.04 AMI resolved at apply time"
  value       = data.aws_ami.ubuntu.id
}

output "iam_role_arn" {
  description = "ARN of the EC2 IAM role (SSM-enabled)"
  value       = aws_iam_role.ec2.arn
}
