variable "project_name" {
  description = "Short identifier used in resource names"
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev | staging | prod)"
  type        = string
}

variable "suffix" {
  description = "Random 5-char alphanumeric suffix appended to all resource names"
  type        = string
}

variable "subnet_az_map" {
  description = "Map of AZ name → subnet ID for EC2 placement (one instance per AZ)"
  type        = map(string)
}

variable "ec2_sg_id" {
  description = "Security group ID to attach to each EC2 instance"
  type        = string
}

variable "target_group_arn" {
  description = "ARN of the ALB target group to register instances with"
  type        = string
}

variable "instance_type" {
  description = "EC2 instance type for NGINX servers"
  type        = string
  default     = "t3.micro"
}

variable "key_name" {
  description = "EC2 Key Pair name for SSH access (null = no SSH key)"
  type        = string
  default     = null
}

variable "tags" {
  type    = map(string)
  default = {}
}
