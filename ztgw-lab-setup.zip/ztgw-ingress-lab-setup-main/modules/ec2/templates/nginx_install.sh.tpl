#!/bin/bash
set -euo pipefail

# ── System update & NGINX install ─────────────────────────────────────
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y nginx curl

# Ubuntu auto-starts NGINX on install with the default config.
# Stop it now so the ALB health check never sees a misconfigured server.
systemctl stop nginx
systemctl enable nginx

# ── Discover instance metadata ────────────────────────────────────────
TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" \
        -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
INSTANCE_ID=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
              http://169.254.169.254/latest/meta-data/instance-id)
AZ=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
     http://169.254.169.254/latest/meta-data/placement/availability-zone)
PRIVATE_IP=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
             http://169.254.169.254/latest/meta-data/local-ipv4)

# ── Custom NGINX index page ───────────────────────────────────────────
cat > /var/www/html/index.html <<HTML
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>NGINX — Instance ${instance_index}</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f4f4; text-align: center; padding: 60px; }
    .card { background: #fff; border-radius: 8px; padding: 40px; display: inline-block;
            box-shadow: 0 2px 8px rgba(0,0,0,.15); }
    h1 { color: #333; } p { color: #666; }
    .badge { background: #0073bb; color: #fff; padding: 4px 12px;
             border-radius: 20px; font-size: .85em; }
  </style>
</head>
<body>
  <div class="card">
    <h1>&#x1F7E2; NGINX is running</h1>
    <p><span class="badge">Instance ${instance_index}</span></p>
    <hr>
    <p><strong>Instance ID:</strong> $INSTANCE_ID</p>
    <p><strong>Private IP:</strong> $PRIVATE_IP</p>
    <p><strong>Availability Zone:</strong> $AZ</p>
    <p><strong>Project:</strong> ${project_name} &mdash; ${environment}</p>
  </div>
</body>
</html>
HTML

# ── NGINX site config (includes /health endpoint) ─────────────────────
cat > /etc/nginx/sites-available/default <<'NGINX'
server {
    listen 80 default_server;
    listen [::]:80 default_server;

    root /var/www/html;
    index index.html;

    server_name _;

    location / {
        try_files $uri $uri/ =404;
    }

    location /health {
        access_log off;
        return 200 "OK\n";
        add_header Content-Type text/plain;
    }
}
NGINX

# ── Validate config and start ─────────────────────────────────────────
# Config is fully written before first start — ALB health check on
# /health will succeed from the very first request.
nginx -t && systemctl start nginx
echo "Bootstrap complete — NGINX instance ${instance_index} ready."
