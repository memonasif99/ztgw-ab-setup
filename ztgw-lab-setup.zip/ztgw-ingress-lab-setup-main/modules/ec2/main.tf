########################################################################
# Module: ec2
# Creates:
#   - Data source: latest Ubuntu 22.04 LTS AMI (Canonical)
#   - 2 EC2 instances (one per private-app subnet / AZ)
#   - Target Group attachments (registers instances with ALB TG)
########################################################################

# ── Latest Ubuntu 22.04 LTS AMI ───────────────────────────────────────
data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"] # Canonical official account

  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-*"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }

  filter {
    name   = "architecture"
    values = ["x86_64"]
  }
}

# ── IAM Role for EC2 (SSM Session Manager — no bastion needed) ────────
resource "aws_iam_role" "ec2" {
  name                  = "${local.prefix}-ec2-role"
  force_detach_policies = true

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy_attachment" "ssm" {
  role       = aws_iam_role.ec2.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_iam_instance_profile" "ec2" {
  name = "${local.prefix}-ec2-profile"
  role = aws_iam_role.ec2.name
}

# ── NGINX EC2 Instances ───────────────────────────────────────────────
# Keyed by AZ name (static, plan-time known) so for_each is stable and
# removing one AZ never shifts the index of the other instance.
resource "aws_instance" "nginx" {
  for_each = local.instance_map

  ami                    = data.aws_ami.ubuntu.id
  instance_type          = var.instance_type
  subnet_id              = each.value.subnet_id
  vpc_security_group_ids = [var.ec2_sg_id]
  iam_instance_profile   = aws_iam_instance_profile.ec2.name
  key_name               = var.key_name

  user_data = base64encode(templatefile("${path.module}/templates/nginx_install.sh.tpl", {
    instance_index = each.value.index
    project_name   = var.project_name
    environment    = var.environment
  }))

  user_data_replace_on_change = true

  root_block_device {
    volume_type           = "gp3"
    volume_size           = 20
    encrypted             = true
    delete_on_termination = true

    tags = merge(local.common_tags, {
      Name = "${local.prefix}-nginx-${each.value.index}-root"
    })
  }

  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required" # IMDSv2 enforced
    http_put_response_hop_limit = 1
  }

  tags = merge(local.common_tags, {
    Name = "${local.prefix}-nginx-${each.value.index}"
    Role = "webserver"
    AZ   = each.key
  })
}

# ── Register instances with the ALB Target Group ──────────────────────
resource "aws_lb_target_group_attachment" "nginx" {
  for_each = local.instance_map   # AZ keys are static — safe for for_each

  target_group_arn = var.target_group_arn
  target_id        = aws_instance.nginx[each.key].id
  port             = 80
}

locals {
  prefix = "${var.project_name}-${var.environment}-${var.suffix}"

  # Map of AZ → { subnet_id, index } — AZ keys are static so for_each is plan-time stable.
  instance_map = {
    for idx, az in sort(keys(var.subnet_az_map)) : az => {
      subnet_id = var.subnet_az_map[az]
      index     = idx + 1
    }
  }

  common_tags = merge(var.tags, {
    Module = "ec2"
  })
}
